# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 15:09:06 2024

@author: TEST
"""

import os
import re
import numpy as np
import pandas as pd

"""θ1 ACOS((1+(C2*C3))/(((1+C2^2)^0.5)*((1+C3^2)^0.5)))"""
def spectral_angle_between_points_θ1(wavelengths, spectrum1, spectrum2, weights):
    
    # Ensure the spectra have the same length
    assert len(spectrum1) == len(spectrum2), "Spectra must have the same length"
    
    # Apply weights if provided
    if weights is not None:
        # print("/n spectral_angle_between_points_θ1 /n")
        assert len(weights) == len(spectrum1), "Weights must have the same length as spectra"
    else:
        print("/n spectral_angle_between_points_θ1  /n")
    
    angles_θ1 = []
    for i in range(len(wavelengths) - 1):
        # Extracting wavelengths and intensities for two points
        # wl1, wl2 = wavelengths[i], wavelengths[i+1]
        intensity1, intensity2 = spectrum1[i], spectrum1[i+1]
        intensity1_other, intensity2_other = spectrum2[i], spectrum2[i+1]
        
        
        # Calculating components of the formula
        numerator = 1 + (intensity1 * intensity1_other)   # (1+(C2*C3))
        
        # (((1+(C2-B2)^2)^0.5)*((1+(C3-B3)^2)^0.5))   (((1+C2^2)^0.5)*((1+C3^2)^0.5))
        denominator = (np.sqrt((1 + (intensity1)**2))) * (np.sqrt((1 + (intensity1_other)**2)))
        
        # Calculating angle in radians
        cosine_similarity = numerator / denominator    
        angle_radians = np.arccos(cosine_similarity)*weights[i] 
        # angle_radians = np.arccos(cosine_similarity)
        
        # Converting angle to degrees
        # angle_degrees = np.degrees(angle_radians)
        
        angles_θ1.append(angle_radians)
    
    return angles_θ1

"""θ2 ACOS((1+(ABS(C2-B2)*ABS(C3-B3)))/(((1+(C2-B2)^2)^0.5)*((1+(C3-B3)^2)^0.5)))"""
def spectral_angle_between_points_θ2(wavelengths, spectrum1, spectrum2, weights):
    # Ensure the spectra have the same length
    assert len(spectrum1) == len(spectrum2), "Spectra must have the same length"
    
    # Apply weights if provided
    if weights is not None:
        # print("/n spectral_angle_between_points_θ2  /n")
        assert len(weights) == len(spectrum1), "Weights must have the same length as spectra"
    else:
        print("/n spectral_angle_between_points_θ2  /n")
    
    angles_θ2 = []
    for i in range(len(wavelengths) - 1):
        # Extracting wavelengths and intensities for two points
        # wl1, wl2 = wavelengths[i], wavelengths[i+1]
        intensity1, intensity2 = spectrum1[i], spectrum1[i+1]
        intensity1_other, intensity2_other = spectrum2[i], spectrum2[i+1]
        
        # Calculating differences in intensities
        diff_intensity1 = abs(intensity2 - intensity1)    # (ABS(C2-B2)
        diff_intensity2 = abs(intensity2_other - intensity1_other)  #ABS(C3-B3)
        
        # Calculating components of the formula
        numerator = 1 + diff_intensity1 * diff_intensity2   # (1+(ABS(C2-B2)*ABS(C3-B3)))
        
        # (((1+(C2-B2)^2)^0.5)*((1+(C3-B3)^2)^0.5))
        denominator = (np.sqrt((1 + (intensity2 - intensity1)**2))) * (np.sqrt((1 + (intensity2_other - intensity1_other)**2)))
        
        # Calculating angle in radians
        cosine_similarity = numerator / denominator    
        angle_radians = np.arccos(cosine_similarity)*weights[i]  
        # angle_radians = np.arccos(cosine_similarity)
        
        # Converting angle to degrees
        # angle_degrees = np.degrees(angle_radians)
        
        angles_θ2.append(angle_radians)
    
    return angles_θ2

"""Calculate the distance of the spectral vector"""
def euclidean_distance(spectrum1, spectrum2):
    # Calculate the difference between the two spectral vectors
    diff = spectrum1 - spectrum2
    # print("/ndiff: /n", diff)
    
    squared_diff = diff ** 2
    # pd.DataFrame(squared_diff).to_excel("squared_tiff.xlsx")
    # print("/nsquared_diff: /n", squared_diff)
    
    elementwise_distance = np.sqrt(squared_diff)
    # print("/nelementwise_distance: /n", elementwise_distance)

    # distance = np.sqrt(np.sum(squared_diff))
    return elementwise_distance

# Example usage:

# base_folder = r"E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-SDG/Cab_30_70_LAI/"
# base_folder = r"E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-SDG/Cab_30_70_LAI/"
base_folder = r"E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-SDG/Cab_30_70_LAI3/"

# folders = ["Cab_30_35","Cab_35_40","Cab_40_45","Cab_45_50","Cab_50_55","Cab_55_60","Cab_60_65","Cab_65_70"]
# folders = ['LAI1015-Cab3070','LAI1520-Cab3070','LAI2025-Cab3070',
#            'LAI2530-Cab3070','LAI3035-Cab3070','LAI3540-Cab3070','LAI4045-Cab3070']

folders = ['Cab5570_LAI0545']

# file_patterns = [
#     r"Cab_/d{2}_/d{2}_CWT_ALL_MEAN.xlsx",
#     r"Cab_/d{2}_/d{2}_Original_ALL_MEAN.xlsx",
#     r"Cab_/d{2}_/d{2}_SG/+MSC_ALL_MEAN.xlsx"]

file_patterns = [r"Cab5570-LAI0545-FD.xlsx",r"Cab5570-LAI0545-old.xlsx"]

results_df_θ1 = pd.DataFrame()
results_df_θ2 = pd.DataFrame()

# Compile regular expressions
pattern = "|".join(file_patterns)
regex = re.compile(pattern)

for folder in folders:

    folder_path = os.path.join(base_folder, folder)
    print(f"/n======================={folder}=======================/n")
    
    excel_files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]
    
    for excel_file in excel_files:
        file_path = os.path.join(folder_path, excel_file)
        print(f"{excel_file}")
        
        if regex.match(excel_file):
            excel_path = os.path.join(excel_file)
            print(f"{excel_path}/n")
            
            df = pd.read_excel(file_path)
            
            wavelengths = df.iloc[:,0].values
            wavelengths_θ = df.iloc[:-1,0].values
            results_df_θ1["Wavelength"] =wavelengths_θ
            results_df_θ2["Wavelength"] =wavelengths_θ
            
            # Example usage within a loop
            for i in range(len(df.columns) - 1):  # assuming df has more than 5 columns
                spectrum1 = df.iloc[:, i+1].values
                for j in range(i + 2, len(df.columns)):
                    spectrum2 = df.iloc[:, j].values
                    
                    # Calculate weights and exponential weights
                    weights = euclidean_distance(spectrum1, spectrum2)
                    weights_exp = np.exp(weights)
                    
                    image_name = f"{excel_file[:-5]}" 
                    
                    # Calculate angles for θ1
                    angles_weight_θ1 = spectral_angle_between_points_θ1(wavelengths, spectrum1, spectrum2, weights_exp)
                    
                    # Calculate angles for θ2
                    angles_weight_θ2 = spectral_angle_between_points_θ2(wavelengths, spectrum1, spectrum2, weights_exp)
                    
                    # column_name_θ1 = f"{image_name}_angles_weight_θ1_{i+1}_{j}"
                    # column_name_θ2 = f"{image_name}_angles_weight_θ2_{i+1}_{j}"
                    
                    column_name_θ1 = f"angles_weight_θ1_{i+1}_{j}"
                    column_name_θ2 = f"angles_weight_θ2_{i+1}_{j}"
                   
                    results_df_θ1[column_name_θ1] = angles_weight_θ1
                    
                    results_df_θ2[column_name_θ2] = angles_weight_θ2
                    
                else:
                    print("False !!/n")
                
            results_df_θ1.to_excel(f"{folder_path}/{image_name}_angles_weight_θ1_combined.xlsx",index=False)  
            print(f" {folder_path}/{image_name}_angles_weight_θ1_combined.xlsx")
            
            results_df_θ2.to_excel(f"{folder_path}/{image_name}_angles_weight_θ2_combined.xlsx",index=False)  
            print(f" {folder_path}/{image_name}_angles_weight_θ1_combined.xlsx")
            
            results_df_θ1 = pd.DataFrame()
            results_df_θ2 = pd.DataFrame()
                       
            
            
            
            
            
            

"""
# file_path = r"E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-SDG/Cab_30_70_LAI/Cab_30_35/Cab_30_35_SG+MSC_ALL_MEAN.xlsx"
# df = pd.read_excel(file_path) 
   
# wavelengths = df.iloc[:,0].values

# Example usage within a loop
for i in range(len(df.columns) - 1):  # assuming df has more than 5 columns
    spectrum1 = df.iloc[:, i+1].values
    for j in range(i + 2, len(df.columns)):
        spectrum2 = df.iloc[:, j].values
        
        # Calculate weights and exponential weights
        weights = euclidean_distance(spectrum1, spectrum2)
        weights_exp = np.exp(weights)
        
        # Calculate angles for θ1
        angles_weight_θ1 = spectral_angle_between_points_θ1(wavelengths, spectrum1, spectrum2, weights_exp)
        pd.DataFrame(angles_weight_θ1).to_excel(f"angles_weight_θ1_{i+1}_{j}.xlsx")
        
        # Calculate angles for θ2
        angles_θ2 = spectral_angle_between_points_θ2(wavelengths, spectrum1, spectrum2, weights_exp)
        pd.DataFrame(angles_θ2).to_excel(f"angles_θ2_{i+1}_{j}.xlsx")

# spectrum1 = df.iloc[:,1].values
# spectrum2 = df.iloc[:,2].values    

# weights = euclidean_distance(spectrum1, spectrum2)
# weights_exp = np.exp(weights)
# pd.DataFrame(weights_exp).to_excel("weights_exp.xlsx")

# angles_weight_θ1 = spectral_angle_between_points_θ1(wavelengths, spectrum1, spectrum2, weights_exp)
# pd.DataFrame(angles_weight_θ1).to_excel("angles_weight_θ1.xlsx")

# angles_θ2 = spectral_angle_between_points_θ2(wavelengths, spectrum1, spectrum2, weights_exp)
# pd.DataFrame(angles_θ2).to_excel("angles_θ2_weights_exp.xlsx")

# print("Spectral angles between consecutive points:")
# for i in range(len(wavelengths) - 1):
#     print(f"At {wavelengths[i]} nm and {wavelengths[i+1]} nm: {angles_θ2[i]} degrees")
"""