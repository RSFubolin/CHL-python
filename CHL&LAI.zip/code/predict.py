# -*- coding: utf-8 -*-
"""
Created on Sun Sep  1 22:42:58 2024

@author: TEST
"""

import warnings
import numpy as np
import pandas as pd
from tqdm import tqdm  
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
import ngboost
from ngboost.learners import default_tree_learner
from sklearn.tree import DecisionTreeClassifier,DecisionTreeRegressor
from ngboost.distns import k_categorical, Bernoulli,Normal,Exponential
from ngboost.scores import LogScore, CRPScore
from ngboost import NGBRegressor
from ngboost.distns import Bernoulli,Normal
from ngboost.scores import LogScore
from sklearn.tree import DecisionTreeRegressor
warnings.filterwarnings("ignore")
from sklearn.utils import shuffle
# from lightgbm import LGBMRegressor
from sklearn.tree import ExtraTreeRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error,mean_absolute_error
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C


"""Prediction model"""
def hy_rf(x_train, y_train, x_test, y_test, option, random_state, label, gap_nm):
    '''
    
    functs：
    
    Train the regression model
    
    Pars：
    
    x_train ：Training data features.
    y_train ：Training data labels.
    x_test ：Test data features
    y_test：Test data label.
    
    option ：Model scheme marke.
    
    '''
    
    output_file = r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/Cab-45-55/LAI2535-RF/'
    
    best_test_r2 = float('-inf') 
    best_state = None 
    
    random_states = random_state    
    
    for state in random_states:
        print("/ngiven random_state:", state)
    
        # RF
        rf = RandomForestRegressor(random_state=state)
        rf.fit(x_train, y_train)
        
        # PLS
        # pls = PLSRegression()
        # pls.fit(x_train, y_train)
        
        # XGB
        # xgb = XGBRegressor()
        # xgb.fit(x_train, y_train)
        
        # NGBoost
        # ngb_params = {
        #                 'n_estimators': 300,
        #                 'Dist': Normal,
        #                 'Score': LogScore,
        #                 'natural_gradient': True,
        #                 'random_state':state,
        #                 'learning_rate': 0.01,
        #                 'Base':default_tree_learner,
        #                 'verbose_eval':100,
        #               }
        #
        # ngb = NGBRegressor(**ngb_params)
        # ngb.fit(x_train, y_train)
        
        # LGM
        # lgbm = LGBMRegressor(random_state=state)
        # lgbm.fit(x_train, y_train)
        
        
        y_train_pred = rf.predict(x_train)
        y_test_pred = rf.predict(x_test)
        
        # plt.scatter(y_test,y_test_pred)
        # plt.show()
        
        
        # Calculation accuracy index
        Test_R2 = r2_score(y_test, y_test_pred)  
        Train_R2 = r2_score(y_train, y_train_pred) 
        Test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred)) 
        Train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred)) 
        
       
        if Test_R2 > best_test_r2:
            best_test_r2 = Test_R2
            best_state = state
    
        if option == 'One':
            print('group-1:')
        elif option == 'Two' or option == 'Two-ABS':
            print('group-2:')
        
        print('RF_Test_R2 :', round(Test_R2, 3), 'RF_Test_rmse',  round(Test_rmse,3))
        print('RF_Train_R2:', round(Train_R2, 3), ' RF_Train_rmse', round(Train_rmse,3))
        
    
    print('best_test_r2', best_test_r2) 
    print('best_state', best_state)
    
    '''
    rf_best = RandomForestRegressor(random_state=best_state)
    rf_best.fit(x_train, y_train)
    
    
    y_train_pred_best = rf_best.predict(x_train)
    y_test_pred_best = rf_best.predict(x_test)
    
    data_pred_poly = pd.concat([pd.DataFrame(y_test,columns=['Test']), pd.DataFrame(y_test_pred_best, columns=['Pred'])], axis=1)
    data_pred_poly.to_excel(f'{output_file}-{label}0%S-pls.xlsx', index = False)'''

    
    data_pred_poly = pd.concat([pd.DataFrame(y_test, columns=['Test']), pd.DataFrame(y_test_pred, columns=['Pred'])], axis=1)
    # print('y_test_pred:',y_test_pred)
    data_pred_poly.to_excel(f'{output_file}-{label}0%S-ngb-{gap_nm}nm.xlsx', index=False)
    
    
    final_test_r2 = r2_score(y_test, y_test_pred)
    final_train_r2 = r2_score(y_train, y_train_pred)
    final_test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    final_train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))

    
    return {
            'best_test_r2': best_test_r2,
            'best_random_state：': best_state,
            'final_test_r2':final_test_r2,
            'final_train_r2':final_train_r2,
            'final_test_rmse':final_test_rmse,
            'final_train_rmse':final_train_rmse
            } 

def find_best_random_state(test_data,train_data,Cab_columns, shuf_random_state, rds, label, gap_nm):
    
    
    num_rows = len(test_data)
    num_to_sample = int(num_rows * 0.7)

    shuf_best_r2 = float('-inf')
    shuf_best_state = None
          
    shuf_random_states = shuf_random_state

    for shuf_state in shuf_random_states:
        
        print("/ngiven shuf_random_state:", shuf_state)

        train_data.columns = test_data.columns

        # Randomly select the measured data
        test_data_shuffled = shuffle(test_data, random_state=shuf_state)  
        sampled_data = test_data_shuffled.head(num_to_sample)  
        
        remaining_data = test_data_shuffled.tail(num_rows - num_to_sample)
        updated_train_data = pd.concat([train_data, sampled_data], ignore_index=True)
        updated_train_data = shuffle(updated_train_data,random_state=shuf_state)
        
        '''Dominated by measured data 
            - 100% measured data gradually added to simulated data'''

        # 一、train ：70%measure； test ：30%measure 
        y_train = sampled_data[Cab_columns]     
        x_train = sampled_data.drop(['Cab'],axis=1)
        
        y_test = remaining_data[Cab_columns]
        x_test = remaining_data.drop(['Cab'],axis=1)
        
        # 二、Randomly extract percentage data from the simulated data
        train_num_rows = len(train_data)
        ratio = float(f"{label}") / 10.0
        train_num_to_sample = int(train_num_rows * ratio) # Sampling ratio
        train_data_shuffled = shuffle(train_data, random_state=shuf_state)  
        simulate_train_data_sampled = train_data_shuffled.head(train_num_to_sample)  
        # simulate_train_data_sampled.to_excel(f'{output_file}train_data_sampled_{label}0%S_simulated.xlsx',index=False) 
        
        # simulate_train_data_sampled add to test_data
        simulate_measure_data_com = pd.concat([simulate_train_data_sampled,test_data],ignore_index=True)      
        # simulate_measure_data_com.to_excel(f'{output_file}simulate_measure_data_com_com_{label}0%S.xlsx',index=False)   
        
        num_rows_com = len(simulate_measure_data_com)
        num_to_sample_com = int(num_rows_com * 0.7)
        train_test_data_shuffled = shuffle(simulate_measure_data_com, random_state=shuf_state)  
        
        train_data_com = train_test_data_shuffled.head(num_to_sample_com) 
        # train_data_com.to_excel(f'{output_file}train_data_com_train.xlsx',index=False) 
        
        test_data_com = train_test_data_shuffled.tail(num_rows_com - num_to_sample_com) 
        # test_data_com.to_excel(f'{output_file}test_data_com_test.xlsx',index=False) 
        
        y_train_com = train_data_com[Cab_columns].values
        x_train_com = train_data_com.drop(['Cab'],axis=1).values
        
        y_test_com = test_data_com[Cab_columns].values
        x_test_com = test_data_com.drop(['Cab'],axis=1).values
        
        random_states = rds
        labels = label
        
        metrics = hy_rf(x_train = x_train_com, y_train = y_train_com, 
                        x_test = x_test_com, y_test = y_test_com, option="Two", random_state = random_states, label = labels, gap_nm=gap_nm)
        
        
        shuf_test_r2 = metrics['best_test_r2']
        print('shuf_test_r2 :', round(shuf_test_r2, 3))
                
        if shuf_test_r2 > shuf_best_r2:
            shuf_best_r2 = shuf_test_r2
            shuf_best_state = shuf_state
            print("shuf_best_r2:",shuf_best_r2)
            print("shuf_state", shuf_state)  
            
        
    print('shuf_best_r2: ', shuf_best_r2)
    print('shuf_best_state:', shuf_best_state)
    
    return {'shuf_best_random_state':shuf_best_state, 'shuf_best_r2':shuf_best_r2}

    
# spectal resolution
gap_nm = 15

train_file =  f'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/Cab-45-55/Cab-45-55-LAI2535/Cab-45-55-LAI2535_FD_mean_{gap_nm}nm_corr_match_F_100_6.xlsx' 
train_data = pd.read_excel(train_file)

test_file = r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/satellites/SDG-Cab-45-55-T.xlsx'
test_data = pd.read_excel(test_file,sheet_name='Sheet1')

Cab_columns = ['Cab']


y_train_1 = train_data[Cab_columns]
x_train_1 = train_data.drop(['Cab'],axis=1)

y_test_1 = test_data[Cab_columns]
x_test_1 = test_data.drop(['Cab'],axis=1)


# hy_rf(x_train = x_train_1, y_train = y_train_1, x_test = x_test_1, y_test = y_test_1, option="One")    

rds = range(1,50)
rds = [23]

shuf_random_state = range(1,50)
shuf_random_state = [1]

# sampling ratio
label = 5

results = find_best_random_state(test_data, train_data, Cab_columns, shuf_random_state, rds, label, gap_nm)   
print(results)

# help(NGBRegressor)
