"""
Created on Fri Jul 12 09:15:47 2024

@author: TEST
"""

"""
    The training database is optimized by using active learning combined with Euclidean distance (AL-EBD)
    Improve the efficiency and accuracy of the model
"""

"""
    step-1 : Initial sample quantity
    
    step-2 : Active learning choice
    
    step-3 : AL-EDB Process
            ①Initialization
            ②Model training and prediction
            ③EDB calculation
            ④Sample selection
            ⑤Mark the new sample
            
    step-4 : Iterate the above process multiple times
    
    step-5 : Add data
    
    step-6 : Finish
"""
import warnings
import numpy as np
import pandas as pd
from tqdm import tqdm  
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
warnings.filterwarnings("ignore")
# from lightgbm import LGBMRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.tree import ExtraTreeRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import AdaBoostRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import r2_score, mean_squared_error,mean_absolute_error
from sklearn.linear_model import LinearRegression, Ridge, Lasso
import warnings
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF
from scipy.spatial.distance import euclidean
warnings.filterwarnings("ignore", category=UserWarning)


# 1. Excel files
# file_path = r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-Sentinel/Cab_45_55/Cab_45_55_LAI3545/Cab_45_55_LAI3545_FD_mean_20nm_corr_match_F.xlsx'
# file_path = r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/Cab-45-55/Cab-45-55-LAI2535/Cab-45-55-LAI2535_FD_mean_15nm_corr_match_F.xlsx'
file_path = r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/satellites/SDG-Cab-45-55_FD.xlsx' 
df = pd.read_excel(file_path)  

# start_column = 400
# end_column = 2500
# X_init = df.loc[:, start_column:end_column].values
X_init = df.drop('Cab', axis=1).values

Cab_columns = ['Cab']
y_init = df[Cab_columns].values

def active_learning(X, y, n_select, max_training_samples):
    """
        X : Feature of Variable
        y : Target of Variable
        n_select : selected sample by AL
        n_iterations : number
    """
    
    rmse_scores = []
    
    selected_sample_counts = []
    
    selected_indices = []
    
    initial_indices = np.random.choice(len(X), size=n_select, replace=False)
    selected_indices.extend(initial_indices)
    
    # kernel = 1.0 * RBF(length_scale=1.0)
    # model = GaussianProcessRegressor(kernel=kernel, random_state=0)
    model = RandomForestRegressor()
    
    min_rmse = 5
    
    while len(selected_indices) < max_training_samples:
        X_train = X[selected_indices]
        y_train = y[selected_indices]
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Predict the output of all unselected samples
        unselected_indices = np.setdiff1d(np.arange(len(X)), selected_indices)
        y_pred = model.predict(X[unselected_indices])
        
        # RMSE
        rmse = np.sqrt(mean_squared_error(y[unselected_indices], y_pred))
        rmse_scores.append(rmse)
        
        # rmse_scores
        avg_rmse = np.mean(rmse_scores)

        if rmse < avg_rmse:
           # Update the minimum RMSE 
           min_rmse = rmse
           print("minRMSE: ", min_rmse)
           
           distances = [min([euclidean(x, x_train) for x_train in X_train]) for x in X]
           
           max_distance_index = np.argmax(distances)
           print("max_distance_index : ", max_distance_index)
           
           # add samples
           selected_indices.append(max_distance_index)
        
        # recored the marked sample
        selected_sample_counts.append(len(selected_indices))
            
        print(f"Iteration {len(rmse_scores)} - RMSE: {rmse:.4f}, Selected Samples: {len(selected_indices)}")    
    return rmse_scores,selected_indices

# Processing
max_training_samples = 50
r2_scores,selected_indices = active_learning(X_init, y_init, n_select=5, max_training_samples=max_training_samples)

# dataset
X_final = X_init[selected_indices]
y_final = y_init[selected_indices]

# output
data_concat = pd.concat([pd.DataFrame(y_final,columns=['Cab']), pd.DataFrame(X_final)],axis = 1) 
data_concat.columns = df.columns
# data_concat.to_excel(r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/Cab-45-55/Cab-45-55-LAI2535/Cab-45-55-LAI2535_FD_mean_15nm_corr_match_F_100_6特征.xlsx',index=False)
data_concat.to_excel(r'E:/syj/PROSAIL+MLR/2024-05-10/PROSAIL-LAI-golden-SDG/satellites/SDG-Cab-45-55-T.xlsx',index=False)






