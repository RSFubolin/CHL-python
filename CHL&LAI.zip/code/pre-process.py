# -*- coding: utf-8 -*-
"""
Created on Sat Jun  8 11:45:33 2024

@author: TEST

"""

import os
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
from scipy import signal
import pandas as pd
import itertools
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize


"""Define the index function for finding column names"""
def get_column_index(df, column_name):
    try:
        return df.columns.get_loc(column_name)
    except KeyError:
        # If the column name is not found, you can choose to return -1 
        # or other appropriate values
        return -1  

"""SG spectral smoothing filtering"""
def SG(data, w=11, p=2):
    """
       :param data: raw spectrum data, shape (n_samples, n_features)
       :param w: int
       :param p: int
       :return: data after SG :(n_samples, n_features)
    """
    return signal.savgol_filter(data, w, p)

"""MSC"""
def do_msc(input_data):
    """
        :param data: raw spectrum data, shape (n_samples, n_features)
        :return: data after MSC :(n_samples, n_features)
   """
    # Calculate the average spectrum as a reference
    ref_spectrum = np.mean(input_data, axis=0)
    corrected_data = np.zeros_like(input_data)
 
    for i in range(input_data.shape[0]):
    
        fit = np.polyfit(ref_spectrum, input_data[i, :], 1)
        
        corrected_data[i, :] = (input_data[i, :] - fit[1]) / fit[0]
 
    return corrected_data, ref_spectrum

"""CHL content plotting"""
def spectrum_ploter(x, yS, df_sort):
    '''
        :param x_D：Spectrum Wavelength
        :param y_D：Reflectance Data
        :param df_sort：set colors
    '''
    
     
    plt.figure(figsize=(10, 6))  
    for i in range(len(yS)):
        color = scalar_map.to_rgba(df_sort['Cab'][i])
        if yS is y:
            i
        else:
            i-=1
        plt.plot(x, yS[i], color=color, linewidth= 0.7)  
    cbar = plt.colorbar(scalar_map, ticks=np.arange(30, 35, 1), label='Cab (μg/cm$^{2}$)')
    cbar.ax.set_yticklabels(np.arange(30, 35, 1))        
    plt.xlabel('Wavelength (nm)')  
    plt.ylabel('Reflectance')  
    plt.tick_params(direction='in')
    plt.xticks(range(400, 2501, 100))
    plt.xticks(rotation=45)
    plt.xlim(400, 2500)
    plt.ylim(0.0, 0.7)
    plt.ylabel('Reflectance')    
        
    plt.show() 

"""First-order Derivative processing of spectra"""
def D1(sdata):
    """
    First-order Derivative
    """
    temp1 = pd.DataFrame(sdata)
    temp2 = temp1.diff(axis=1)
    temp3 = temp2.values
    return np.delete(temp3, 0, axis=1)

"""Spectral resampling: Averaging method"""    
def resample_spectra(resample_data, start_column, end_column, R, directory2, last_folder2, key_name):
    """
    
    Parameters:
    file_path (str): Enter the path of the Excel file
    start_column (int): The starting column names of the spectral data to be extracted
    end_column (int): The spectral data to be extracted ends the column names
    R (list): List of sampling scales
    output_file_template (str):  f'output_path_mean_{R[i]}nm.xlsx'
    Name : Save the identifier of the file
    """
    # Read data
    all_data = resample_data
    Cab_columns = ['Cab']
    Cab_data = all_data[Cab_columns]
    all_spe = all_data.loc[:, start_column:end_column]
    results = []

    for i in range(len(R)):
        newband = np.arange(start_column, end_column + 1, R[i])
        row = all_spe.shape[0]
        Cab_data = pd.DataFrame(Cab_data)
        
        # Store the mean value
        mean_columns = []
        num_columns = all_spe.shape[1]

        for j in range(0, num_columns, R[i]):
            extracted_data = all_spe.iloc[:, j:j + R[i]]
            data_mean = extracted_data.mean(axis=1)
            col_name = str(j + start_column)
            mean_df = pd.DataFrame(data_mean, columns=[col_name])
            mean_columns.append(mean_df)

        averages = pd.concat(mean_columns, axis=1)
        Cab_averages = pd.concat([Cab_data, averages], axis=1)
        Cab_averages.to_excel(os.path.join(directory2, f'{last_folder2}_{key_name}_mean_{R[i]}nm.xlsx'), index=False)

        # output_file_path = output_file_template.format(R[i])

        # Cab_averages.to_excel(output_file_path, index=False)
        print(f"\nMean resample finished {R[i]} nm!\n")
        
        results.append(Cab_averages)
        
    return results


# Set the path of the main directory
main_directory = r'E:\syj\PROSAIL+MLR\2024-05-10\PROSAIL-LAI-golden-SDG'

# Obtain the list of subdirectories of the first level
first_level_dirs = [f.path for f in os.scandir(main_directory) if f.is_dir()]

for directory1 in first_level_dirs:
    last_folder1 = os.path.basename(directory1)
    print(f"{main_directory}*****Directory name：",last_folder1)

    # Obtain the list of subdirectories at the second level
    second_level_dirs = [f.path for f in os.scandir(directory1) if f.is_dir()]
     
    for directory2 in second_level_dirs:
        last_folder2 = os.path.basename(directory2)
        print(f"{directory1}\n*****Directory name：", last_folder2)
        print("=======================================NEXT NEO=======================================")

        print(f"{last_folder2}*****File directory：",last_folder2)
        
        # 导入数据
        excel_file = os.path.join(directory2, f'{last_folder2}.xlsx')
        print(f"{last_folder2}*****The file writing is completed.！！")
    
        wave1 = pd.read_excel(excel_file)
    
        Cab_columns = ['Cab']
        cab = wave1[Cab_columns]
    
        start_column = 400
        end_column = 2500
    
        wav = wave1.loc[:, start_column:end_column].values

        df_sort = wave1.sort_values(by='Cab').reset_index(drop=True)
    
        y_SG = SG(wav)
        print(f"{last_folder2}*****SG！！")
        
        corrected_spectra, mean_spectrum = do_msc(y_SG)
        print(f"{last_folder2}*****！！")
    
        start_index = get_column_index(wave1, start_column)
        end_index = get_column_index(wave1, end_column)

        x = wave1.columns[start_index:end_index+1]

        Cab_spec = pd.concat([cab,pd.DataFrame(wav,columns=x)],axis=1)
        Cab_spec.to_excel(os.path.join(directory2, f'{last_folder2}-Original-spectrum.xlsx'), index=False)
        print(f"{last_folder2}*****")
        
        Cab_spec_mean = Cab_spec.iloc[:,1:].mean()
        Cab_spec_mean.to_excel(os.path.join(directory2, f'{last_folder2}.xlsx'), index=False)
        print(f"{last_folder2}*****")
        
    
        # 仅包含Cab和反射率（已完成SG+MSC处理）--使用处理后的光谱数据进行计算光谱与叶绿素相关性
        Cab_ref = pd.concat([cab,pd.DataFrame(corrected_spectra,columns=x)],axis=1)
        Cab_ref.to_excel(os.path.join(directory2, f'{last_folder2}_SG+MSC.xlsx'), index=False)
        print(f"{last_folder2}*****")
        
        Cab_ref_mean = Cab_ref.iloc[:,1:].mean()
        Cab_ref_mean.to_excel(os.path.join(directory2, f'{last_folder2}_SG+MSC.xlsx'), index=False)
        print(f"{last_folder2}*****")
    
        # Calculate the correlation matrix
        corr_matrix = Cab_ref.corr()
        corr_matrix.to_excel(os.path.join(directory2, 'SG+MSC-corr.xlsx'))
        print(f"{last_folder2}*****")
    
        Cab_Bands_R2 = corr_matrix.iloc[1:,0:1]
        Cab_Bands_R2_reset = Cab_Bands_R2.reset_index()
        numpy_array_with_index = Cab_Bands_R2_reset.values
        pd_array_with_index = pd.DataFrame(numpy_array_with_index)

        pd_array_with_index.columns = ['Wavelenght', 'Correlation']
        pd_array_with_index.to_excel(os.path.join(directory2, 'SG+MSC-pre-corr.xlsx'), index=False)
        print(f"{last_folder2}*****")

        x = wave1.columns[start_index:end_index+1]

        y = wave1.iloc[:, start_index:].values

        norm = Normalize(vmin=cab.min(), vmax=cab.max())  
        cmap = plt.get_cmap('RdYlGn') # https://blog.csdn.net/BaiJing1999/article/details/102158097
        scalar_map = ScalarMappable(norm=norm, cmap=cmap)

        y_old =Cab_spec.loc[:, start_column:].values 
        # old_ploter = spectrum_ploter(x, y_old, df_sort)
        print(f"{last_folder2}*****")

        y_new =Cab_ref.loc[:, start_column:].values 
        # new_ploter = spectrum_ploter(x, y_new, df_sort)
        print(f"{last_folder2}*****")
    
        spec_D1 = D1(corrected_spectra)
        print(f"{last_folder2}*****")

        real_parts_df = pd.DataFrame(spec_D1,columns=range(400,2500))
        concat_data = pd.concat([cab,real_parts_df],axis=1)
        concat_data.to_excel(os.path.join(directory2,f'{last_folder2}_FD.xlsx'),index=False)
        print(f"{last_folder2}*****")
        
        concat_data_mean = concat_data.iloc[:,1:].mean()
        concat_data_mean.to_excel(os.path.join(directory2, f'{last_folder2}_FD_spectrum.xlsx'), index=False)
        print(f"{last_folder2}*****")

        print("========================Perform spectral resampling========================")

        resample_data = concat_data
        start_column = 400
        end_column = 2499
        R = [1, 3, 5, 7, 10, 15, 20]
        Cab_averages_list = resample_spectra(resample_data, start_column, end_column, R, directory2, last_folder2, key_name='FD')
        print("========================Complete spectral resampling========================")
        
        print("========================Calculate the correlation between chlorophyll and spectral bands========================")            
        # 计算相关性矩阵
        for R_i in tqdm(range(len(R))):
            corr_matrix = Cab_averages_list[R_i].corr()
            print(f"{last_folder2}*****")
            # print(f"Correlation matrix for scale {R[R_i]}:\n", corr_matrix)
        

            # sorted_corr_matrix = corr_matrix.iloc[1:,0].sort_values(ascending=False) #排序
            sorted_corr_matrix = corr_matrix.iloc[1:,0] 
            sorted_corr_matrix = pd.DataFrame(sorted_corr_matrix)
            sorted_corr_matrix.columns = ['R']
            # Cab_30_35_LAI0510_CWT_31_mean_{R[i]}nm_corr.xlsx
        
            sorted_corr_matrix.to_excel(os.path.join(directory2,f'{last_folder2}_FD_mean_{R[R_i]}nm_corr.xlsx'))
            print(f"{last_folder2}*****{R[R_i]}nm")

            extra_F = []
            for i in range(len(sorted_corr_matrix)):
                if ((sorted_corr_matrix.iloc[i]).abs() >= 0.19).item():
                    extra_F.append(sorted_corr_matrix.iloc[i])
        
            extra_F = pd.DataFrame(extra_F)
            extra_F = extra_F.sort_index(ascending=True)
        
            Cab_ref_extra_F = []
            for i in extra_F.index:
                if int(i) in concat_data.columns:
                    Cab_ref_extra_F.append(concat_data[int(i)])
            Cab_ref_extra_F = pd.DataFrame(Cab_ref_extra_F)
            Cab_ref_match_F = pd.concat([cab, Cab_ref_extra_F.T], axis=1)
            Cab_ref_match_F.to_excel(os.path.join(directory2,f'{last_folder2}_FD_mean_{R[R_i]}nm_corr_match_F.xlsx'),index=False)
            
            print(f"{last_folder2}*****")
            print(f'FD_And_Match_Finished')
            print(f"================Finished{last_folder2}================")


        """Resampling part - in-situ spectroscopy"""

        resample_data_SG = Cab_ref
        start_column_SG = 400
        end_column_SG = 2500
        R = [1, 3, 5, 7, 10, 15, 20]
        Cab_averages_list_SG = resample_spectra(resample_data_SG, start_column_SG, end_column_SG, R, directory2, last_folder2, key_name='SG')


        for R_i in tqdm(range(len(R))):
            corr_matrix = Cab_averages_list_SG[R_i].corr()
            print(f"{last_folder2}*****")
            # print(f"Correlation matrix for scale {R[R_i]}:\n", corr_matrix)
        
            sorted_corr_matrix = corr_matrix.iloc[1:,0].sort_values(ascending=False)
            sorted_corr_matrix = pd.DataFrame(sorted_corr_matrix)
            sorted_corr_matrix.columns = ['Correlation']
            # Cab_30_35_LAI0510_CWT_31_mean_{R[i]}nm_corr.xlsx
        
            sorted_corr_matrix.to_excel(os.path.join(directory2,f'{last_folder2}_SG_mean_{R[R_i]}nm_corr.xlsx'))
            print(f"{last_folder2}*****{R[R_i]}nm")
        
            extra_F = []
            for i in range(len(sorted_corr_matrix)):
                if ((sorted_corr_matrix.iloc[i]).abs() >= 0.1).item():
                    extra_F.append(sorted_corr_matrix.iloc[i])
        
            extra_F = pd.DataFrame(extra_F)
            extra_F = extra_F.sort_index(ascending=True)
        
            Cab_ref_extra_F = []
            for i in extra_F.index:
                if int(i) in Cab_ref.columns:
                    Cab_ref_extra_F.append(Cab_ref[int(i)])
            Cab_ref_extra_F = pd.DataFrame(Cab_ref_extra_F)
            Cab_ref_match_F = pd.concat([cab, Cab_ref_extra_F.T], axis=1)
            Cab_ref_match_F.to_excel(os.path.join(directory2,f'{last_folder2}_SG_mean_{R[R_i]}nm_corr_match_F.xlsx'),index=False)
            
            print(f"{last_folder2}*****")
            print(f'FD_And_Match_Finished')
            print(f"================Finished{last_folder2}================")
        

